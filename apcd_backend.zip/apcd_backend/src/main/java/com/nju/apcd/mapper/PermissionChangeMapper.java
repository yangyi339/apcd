package com.nju.apcd.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nju.apcd.pojo.PermissionChange;
import org.springframework.stereotype.Repository;

@Repository
public interface PermissionChangeMapper extends BaseMapper<PermissionChange> {
}
