package com.nju.apcd.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nju.apcd.pojo.EventLog;
import org.springframework.stereotype.Repository;

@Repository
public interface EventLogMapper extends BaseMapper<EventLog> {
}
