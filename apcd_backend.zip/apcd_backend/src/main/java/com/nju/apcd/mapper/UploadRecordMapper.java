package com.nju.apcd.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.nju.apcd.pojo.UploadRecord;
import org.springframework.stereotype.Repository;

@Repository
public interface UploadRecordMapper extends BaseMapper<UploadRecord> {
}
