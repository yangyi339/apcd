package com.nju.apcd;

/**
 * Author:yy
 * Description:
 **/

class ListNode {
    int val;
    ListNode next = null;

    ListNode(int val) {
        this.val = val;
    }
}
public class Solution {
    public ListNode ReverseList(ListNode head) {
        ListNode p=head.next;
        ListNode q=head;
        if(p!=null){
            while(p!=null){
                q=p;
                p=p.next;
                q.next=head;
            }
            System.out.println(q.val);
            return q;
        }
        System.out.println(head.val);
        return head;

    }

    public static void main(String[] args) {
        ListNode head = new ListNode(5);
        head.next=new ListNode(2);
        head.next.next=new ListNode((1));
        Solution solution = new Solution();
        solution.ReverseList(head);

    }
}
