package com.nju.apcd;

import com.nju.apcd.mapper.EventLogMapper;
import com.nju.apcd.pojo.ServerResponse;
import com.nju.apcd.pojo.param.EventLogQueryParam;
import com.nju.apcd.service.DataProcessService;
import com.nju.apcd.service.impl.DataProcessServiceImpl;
import org.apache.ibatis.annotations.Param;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Author:yy
 * Description:
 **/
@SpringBootTest
public class getEventLogTest {
    @Autowired
    DataProcessService dataProcessService;
    @Test
    public void test01(){
        EventLogQueryParam param = new EventLogQueryParam();
        param.setProject("project4");
        param.setScene("pr");
        param.setCurrentPage("2");
        param.setPageSize("1");
        System.out.println(dataProcessService.getEventLog(param));;
    }
}
